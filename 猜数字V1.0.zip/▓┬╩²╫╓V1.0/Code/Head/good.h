#pragma once
#include"Head test.h"
#include"last.h"
using namespace std;
class goodlast :public last
{
public:
	goodlast(int times, int o_class);
	virtual void showthing();
	virtual string chooseLast();

};