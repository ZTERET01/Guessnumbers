#pragma once
#include<iostream>
#include<random>
#include<fstream>
#include<string>
#include<ctime>
#include<Windows.h>
#include<conio.h>
#include"last.h"
#include<string>
#define FILENAME "thing.txt"
const int NUM_OF_START = 5;

