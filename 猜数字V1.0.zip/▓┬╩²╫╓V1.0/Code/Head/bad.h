#pragma once
#include"Head test.h"
#include"last.h"
using namespace std;
class badlast:public last
{
public:
	badlast(int times,int o_class);
	virtual void showthing();
	virtual string chooseLast();


	
};