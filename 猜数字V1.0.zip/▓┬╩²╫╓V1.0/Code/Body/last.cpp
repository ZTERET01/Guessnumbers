#include"last.h"
last::~last()
{

}