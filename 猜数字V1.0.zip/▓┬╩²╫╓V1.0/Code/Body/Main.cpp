#include"last.h"
#include"Make.h"
#include"bad.h"
#include<iostream>
using namespace std;
int main()
{
	Make MK;
	MK.stsrtpage();
	return 0;
}